package jantarfilosofos;


public enum States {
PENSANDO, TENTANDO_COMER, COMENDO     
}
