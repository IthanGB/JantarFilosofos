package jantarfilosofos;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.Semaphore;

public class JantarFilosofos {

    public static void main(String[] args) throws InterruptedException {
        Scanner input = new Scanner(System.in);

        System.out.println("informe o número de filósofos");
        int numFilosofos = input.nextInt();
        while (numFilosofos < 1) {
            System.out.println("O numero de filosfos nao pode ser menor que 1. Insira um valor válido");

            numFilosofos = input.nextInt();
        }

        System.out.println("informe o tempo em segundos:");
        int timer = input.nextInt();

        while (timer < 1) {
            System.out.println("O tempo nao pode ser menor que 1. Informe um número apropriado de segundos:");
            timer = input.nextInt();
        }
        boolean umPorVez = true;

        boolean mesmaQuantidade = true;

        MesaDeJantar mesa = new MesaDeJantar(new Semaphore(1), umPorVez, mesmaQuantidade, numFilosofos);

        ArrayList<Filosofo> listaFilosofos = new ArrayList<>();

        listaFilosofos.add(new Filosofo("Filosofo 1", mesa, new Semaphore(1), new Semaphore(1)));

        System.out.println("\nCriando filosofos");
        System.out.println("Filosofo 1");
        for (int i = 1; i < numFilosofos - 1; i++) {
            String nome = "Filosofo " + (i + 1);

            System.out.println(nome);

            Semaphore garfoEsq = listaFilosofos.get(i - 1).getGarfoEsq();

            Semaphore garfoDir = new Semaphore(1);

            listaFilosofos.add(new Filosofo(nome, mesa, garfoEsq, garfoDir));
        }

        if (numFilosofos > 1) {
            String nome = "Filosofo " + numFilosofos;
            System.out.println(nome);
            Semaphore garfoEsq = listaFilosofos.get(0).getGarfoDir();
            Semaphore garfoDir = listaFilosofos.get(numFilosofos - 2).getGarfoDir();
            listaFilosofos.add(new Filosofo(nome, mesa, garfoDir, garfoEsq));
        }
        System.out.println("\nInicializando Threads");
        for (Filosofo f : listaFilosofos) {
            new Thread(f).start();
        }

        Thread.sleep(timer * 1000);
        for (Filosofo f : listaFilosofos) {
            f.setContinua();
        }
        Thread.sleep(2000);
        System.out.println("\nEsperando Threads encerrarem");

    }
}
