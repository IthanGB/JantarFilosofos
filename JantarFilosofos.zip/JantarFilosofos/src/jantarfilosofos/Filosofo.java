package jantarfilosofos;

import java.util.Random;
import java.util.concurrent.Semaphore;

public class Filosofo implements Runnable {

    private String nome;
    private int vezesPensou;
    private int vezesTentouComer;
    private int vezesComeu;

    public int getvezesComeu() {
        return vezesComeu;
    }
    private boolean continua;
    private States state;
    private MesaDeJantar mesa;
    private Semaphore garfoDir;
    private Semaphore garfoEsq;
    private Random tempoPensando;

    Filosofo(String nome, MesaDeJantar mesa, Semaphore garfoDir, Semaphore garfoEsq) {
        this.nome = nome;
        this.mesa = mesa;
        this.garfoEsq = garfoEsq;
        this.garfoDir = garfoDir;
        this.vezesPensou = 0;
        this.vezesTentouComer = 0;
        this.vezesComeu = 0;
        this.continua = true;
        this.state = States.PENSANDO;
        this.tempoPensando = new Random();
    }

    String getNome() {
        return nome;

    }

    Semaphore getGarfoDir() {
        return garfoDir;
    }

    Semaphore getGarfoEsq() {
        return garfoEsq;
    }

    void setState(States s) {
        this.state = s;
    }

    void setContinua() {
        this.continua = false;
    }

    void print_state() {
        System.out.println(this.nome + " está no estado: " + this.state);

    }

    private void pensar() throws InterruptedException {
        Thread.sleep(this.tempoPensando.nextInt(4) * 1000);
    }

    private void naoConseguiuComer() throws InterruptedException {
        this.state = States.PENSANDO;
        this.vezesPensou += 1;
        this.print_state();

        this.pensar();
    }

    @Override
    public void run() {
        try {
            this.state = States.PENSANDO;
            this.vezesPensou += 1;
            this.print_state();

            while (this.continua) {
                this.state = States.TENTANDO_COMER;
                this.vezesTentouComer += 1;
                this.print_state();

                if (this.garfoDir.tryAcquire()) {
                    if (this.garfoEsq.tryAcquire()) {
                        if (mesa.comer(this)) {
                            this.garfoEsq.release();
                            this.garfoDir.release();
                            this.vezesComeu += 1;
                        } else {
                            this.garfoEsq.release();
                            this.garfoDir.release();
                            this.naoConseguiuComer();
                        }
                    } else {
                        this.garfoDir.release();
                        this.naoConseguiuComer();

                    }
                } else {
                    this.naoConseguiuComer();
                }
            }

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public String toStrig() {
        return this.nome + "\n\t->Pensou: " + this.vezesPensou + "\n\t->Tentou comer: " + this.vezesTentouComer + "\n\t->Comeu: " + this.vezesComeu + "\n";
    }
}
