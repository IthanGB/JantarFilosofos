package jantarfilosofos;

import java.util.concurrent.Semaphore;

class MesaDeJantar {

    private Semaphore semaforo_comida;
    private boolean umPorVez;
    private boolean mesmaQuantidade;
    private int numFilosofos;
    private int comiloes;
    private int minComida;
    

    MesaDeJantar(Semaphore semaforo_comida, boolean umPorVez, boolean mesmaQuantidade, int numFilosofos) {

        this.semaforo_comida = semaforo_comida;
        this.numFilosofos = numFilosofos;
        this.umPorVez = umPorVez;
        this.mesmaQuantidade = mesmaQuantidade;
        this.comiloes = 0;
        this.minComida = 1;
    }

   

    boolean comer(Filosofo f) throws InterruptedException {
        if (umPorVez) {
            if (mesmaQuantidade) {
                return this.apenasUmComeMesmaQuantidadeSemEsperarMesa(f);
            } else {
                return this.apenasUmComePeloMenosUmaVez(f);
            }
        } else {
            if (mesmaQuantidade) {
                return this.todosComemMesmaQuantidade(f);
            } else {
                return this.todosComemPeloMenosUmaVez(f);
            }
        }
    }

    private boolean apenasUmComePeloMenosUmaVez(Filosofo f) throws InterruptedException {
        if (f.getvezesComeu() == 0 || this.comiloes == this.numFilosofos) {
            if (semaforo_comida.tryAcquire()) {
                f.setState(States.COMENDO);
                f.print_state();
                Thread.sleep(2000);
                if (this.comiloes < this.numFilosofos) {
                    this.comiloes += 1;
                }
                semaforo_comida.release();
                return true;
            } else {
                return false;
            }

        } else {
            return false;

        }

    }

    private boolean apenasUmComeMesmaQuantidadeSemEsperarMesa(Filosofo f) throws InterruptedException {
        if (f.getvezesComeu() < this.minComida) {
            if (semaforo_comida.tryAcquire()) {
                f.setState(States.COMENDO);
                f.print_state();
                Thread.sleep(2000);
                this.comiloes += 1;
                if (this.comiloes == this.numFilosofos) {
                    this.minComida += 1;
                    this.comiloes = 0;
                }
                semaforo_comida.release();
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }

    }

    private boolean todosComemPeloMenosUmaVez(Filosofo f) throws InterruptedException {
        if (f.getvezesComeu() == 0 || this.comiloes == this.numFilosofos) {
            f.setState(States.COMENDO);
            f.print_state();
            Thread.sleep(2000);
            if (this.comiloes < this.numFilosofos) {
                this.comiloes += 1;
            }
            return true;
        } else {
            return false;
        }

    }

    private boolean todosComemMesmaQuantidade(Filosofo f) throws InterruptedException {
        if (f.getvezesComeu() < this.minComida) {
            f.setState(States.COMENDO);
            f.print_state();
            Thread.sleep(2000);
            this.comiloes += 1;
            if (this.comiloes == this.numFilosofos) {
                this.minComida += 1;
                this.comiloes = 0;
            }
            semaforo_comida.release();
            
            return true;
        }else{
            return false;
        }
    }

}
